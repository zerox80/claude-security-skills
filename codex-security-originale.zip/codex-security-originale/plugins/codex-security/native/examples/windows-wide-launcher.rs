// Test-only launcher: Node's Windows startup has already replaced lone surrogates.
#[cfg(not(windows))]
fn main() {}

#[cfg(windows)]
fn main() -> std::io::Result<()> {
    use std::{
        env,
        ffi::OsString,
        fs, io,
        os::windows::{ffi::OsStringExt, fs::OpenOptionsExt},
        path::{Path, PathBuf},
        process::Command,
    };

    fn raw(prefix: &str, unit: u16) -> OsString {
        OsString::from_wide(&prefix.encode_utf16().chain([unit]).collect::<Vec<_>>())
    }

    fn symlink_fixture(create: impl FnOnce() -> io::Result<()>) -> io::Result<bool> {
        match env::var_os("CODEX_SECURITY_TEST_WINDOWS_SYMLINKS") {
            Some(mode) if mode == "disabled" => Ok(false),
            Some(mode) if mode == "required" => create().map(|()| true),
            Some(_) => Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "CODEX_SECURITY_TEST_WINDOWS_SYMLINKS must be disabled or required",
            )),
            None => match create() {
                Ok(()) => Ok(true),
                // Windows requires Developer Mode or the symbolic-link privilege.
                Err(error) if error.raw_os_error() == Some(1314) => Ok(false),
                Err(error) => Err(error),
            },
        }
    }

    fn run(node: OsString, script: OsString, root: &Path) -> io::Result<()> {
        let cwd = root.join(raw("cwd-", 0xd800));
        fs::create_dir(&cwd)?;
        let replacement = root.join("cwd-\u{fffd}");
        fs::create_dir(&replacement)?;
        fs::write(replacement.join("sentinel"), "replacement cwd untouched")?;
        let names = [
            raw("high-", 0xd800),
            raw("high-", 0xfffd),
            raw("low-", 0xdc80),
            raw("low-", 0xfffd),
            raw("tail-", 0xdfff),
            raw("tail-", 0xfffd),
            OsString::from("unicode-🔐-東京"),
        ];
        for (index, name) in names.iter().enumerate() {
            fs::write(cwd.join(name), format!("sentinel-{index}"))?;
        }
        fs::create_dir(cwd.join("empty"))?;
        fs::create_dir(cwd.join(raw("directory-", 0xdc80)))?;
        let symlinks = symlink_fixture(|| {
            std::os::windows::fs::symlink_file(&names[0], cwd.join("file-link"))
        })?;
        if symlinks {
            std::os::windows::fs::symlink_file(raw("missing-", 0xdfff), cwd.join("missing-link"))?;
            std::os::windows::fs::symlink_file("loop-link", cwd.join("loop-link"))?;
            std::os::windows::fs::symlink_dir("empty", cwd.join("directory-link"))?;
            std::os::windows::fs::symlink_dir(
                raw("missing-", 0xdfff),
                cwd.join("dangling-directory-link"),
            )?;
        }
        let locked = cwd.join(raw("locked-", 0xdfff));
        fs::write(&locked, "directory enumeration does not open this file")?;
        fs::write(root.join(raw("parent-", 0xd800)), "parent sentinel")?;
        let verbatim = fs::canonicalize(&cwd)?;
        for (name, contents) in [
            ("trailing", "ordinary dot sibling"),
            ("trailing.", "literal dot file"),
            ("space", "ordinary space sibling"),
            ("space ", "literal space file"),
        ] {
            fs::write(verbatim.join(name), contents)?;
        }
        let arguments = [
            raw("arg-high-", 0xd800),
            raw("arg-low-", 0xdc80),
            raw("arg-tail-", 0xdfff),
            OsString::from("replacement-\u{fffd}"),
            OsString::from("Unicode 🔐 東京"),
            OsString::from(""),
            OsString::from("space and\ttab"),
            OsString::from("quoted \"value\" and trailing\\"),
            OsString::from("backslash\\\"quote"),
        ];
        let guard = fs::OpenOptions::new()
            .read(true)
            .share_mode(0)
            .open(&locked)?;
        let status = Command::new(node)
            .arg(script)
            .arg("wide-worker")
            .arg(root)
            .args(arguments)
            .current_dir(&cwd)
            .env("CODEX_SECURITY_WIDE_VALUE", raw("value-", 0xd800))
            .env("CODEX_SECURITY_WIDE_EMPTY", "")
            .env_remove("CODEX_SECURITY_WIDE_ABSENT")
            .env(raw("CODEX_SECURITY_WIDE_NAME_", 0xdfff), "wide name value")
            .env("CODEX_SECURITY_WIDE_LONG", "x".repeat(1024))
            .env(
                "CODEX_SECURITY_TEST_WINDOWS_HAS_SYMLINKS",
                if symlinks { "1" } else { "0" },
            )
            .env("USERPROFILE", &cwd)
            .status()?;
        if !status.success() {
            return Err(io::Error::other("Wide Windows child proof failed"));
        }
        drop(guard);
        if fs::read(replacement.join("sentinel"))? != b"replacement cwd untouched" {
            return Err(io::Error::other("Replacement cwd was changed"));
        }
        Ok(())
    }

    fn policy_proof(node: OsString, script: OsString, root: &Path) -> io::Result<()> {
        let cwds = [raw("cwd-", 0xd800), raw("cwd-", 0xfffd)];
        let repos = [raw("İrepo-", 0xdc80), raw("İrepo-", 0xfffd)];
        let scopes = [raw("scope-", 0xdfff), raw("scope-", 0xfffd)];
        let replacement_output = raw("out-", 0xfffd);
        let mut sentinels = Vec::new();
        for (ci, cwd) in cwds.iter().enumerate() {
            for (ri, repo) in repos.iter().enumerate() {
                let directory = root.join(cwd).join(repo);
                fs::create_dir_all(&directory)?;
                fs::write(
                    directory.join("SECURITY.md"),
                    if ci == 0 && ri == 0 {
                        "root raw\n"
                    } else {
                        "replacement policy\n"
                    },
                )?;
                let sentinel = directory.join(&replacement_output);
                fs::write(&sentinel, "output sentinel")?;
                sentinels.push(sentinel);
                for (si, scope) in scopes.iter().enumerate() {
                    fs::create_dir(directory.join(scope))?;
                    fs::write(
                        directory.join(scope).join("SECURITY.md"),
                        if ci == 0 && ri == 0 && si == 0 {
                            "scope raw\n"
                        } else {
                            "replacement policy\n"
                        },
                    )?;
                }
            }
        }
        let repo = root.join(&cwds[0]).join(&repos[0]);
        let output_name = raw("out-", 0xdfff);
        let output = repo.join(&output_name);
        let invoke = |command: &str, args: &[PathBuf]| {
            Command::new(&node)
                .arg(&script)
                .args(["--helper", command])
                .args(args)
                .current_dir(&repo)
                .env("USERPROFILE", &repo)
                .output()
        };
        let policy = |args: &[PathBuf]| invoke("resolve-security-md", args);
        for (repo_arg, scope_arg, output_arg) in [
            (repo.clone(), PathBuf::from(&scopes[0]), output.clone()),
            (
                PathBuf::from("~"),
                PathBuf::from("~").join(&scopes[0]),
                PathBuf::from(&output_name),
            ),
            (
                PathBuf::from("."),
                PathBuf::from(&scopes[0]),
                PathBuf::from(&output_name),
            ),
        ] {
            let child = policy(&[
                "--repo".into(),
                repo_arg,
                "--scope".into(),
                scope_arg,
                "--out".into(),
                output_arg,
            ])?;
            if !child.status.success() || !child.stdout.is_empty() || !child.stderr.is_empty() {
                return Err(io::Error::other(format!(
                    "Windows policy helper execution failed ({}): {}",
                    child.status,
                    String::from_utf8_lossy(&child.stderr),
                )));
            }
            let expected = concat!(
                "## SECURITY.md source: \"SECURITY.md\"\r\n\r\nroot raw\r\n\r\n",
                "## SECURITY.md source: \"scope-\\udfff/SECURITY.md\"\r\n\r\nscope raw\r\n",
            );
            if fs::read(&output)? != expected.as_bytes() {
                return Err(io::Error::other(
                    "Windows policy helper selected the wrong path",
                ));
            }
            fs::remove_file(&output)?;
        }
        for scope in [PathBuf::from("."), PathBuf::from(&scopes[0]).join("..")] {
            let child = policy(&["--repo".into(), repo.clone(), "--scope".into(), scope])?;
            let expected = b"## SECURITY.md source: \"SECURITY.md\"\n\nroot raw\n";
            if !child.status.success() || !child.stderr.is_empty() || child.stdout != expected {
                return Err(io::Error::other(
                    "Windows policy helper did not resolve the root scope",
                ));
            }
        }
        let listing = policy(&["--repo".into(), "~".into(), "--list".into()])?;
        let expected =
            b"[\"SECURITY.md\", \"scope-\\udfff/SECURITY.md\", \"scope-\\ufffd/SECURITY.md\"]\n";
        if !listing.status.success() || !listing.stderr.is_empty() || listing.stdout != expected {
            return Err(io::Error::other(
                "Windows policy helper lost directory names",
            ));
        }
        for sentinel in &sentinels {
            if fs::read(sentinel)? != b"output sentinel" {
                return Err(io::Error::other(
                    "Windows policy helper changed a replacement output",
                ));
            }
        }
        let identity_root = root.join("İroot");
        let sibling = root.join("i\u{307}root");
        fs::create_dir(&identity_root)?;
        fs::create_dir(&sibling)?;
        let sibling_policy = sibling.join("SECURITY.md");
        fs::write(&sibling_policy, "sibling policy\n")?;
        let verify_outside_root = |scope: &Path| -> io::Result<()> {
            let result = policy(&[
                "--repo".into(),
                identity_root.clone(),
                "--scope".into(),
                scope.to_path_buf(),
                "--out".into(),
                "-".into(),
            ])?;
            if result.status.code() != Some(2)
                || !result.stdout.is_empty()
                || !String::from_utf8_lossy(&result.stderr).contains("outside the scan root")
            {
                return Err(io::Error::other(
                    "Windows policy helper did not preserve directory identity",
                ));
            }
            Ok(())
        };
        verify_outside_root(&sibling)?;
        let symlinks = symlink_fixture(|| {
            std::os::windows::fs::symlink_file(&sibling_policy, identity_root.join("SECURITY.md"))
        })?;
        if symlinks {
            verify_outside_root(&identity_root)?;
        }
        let input_name = raw("input-", 0xd800);
        let scope_name = raw("scope-files-", 0xdc80);
        fs::write(repo.join("source.py"), "source line\n")?;
        fs::write(repo.join(&scope_name), "./source.py\n./deleted.py\n")?;
        fs::write(repo.join(raw("scope-files-", 0xfffd)), "wrong.py\n")?;
        fs::write(
            repo.join(raw("input-", 0xfffd)),
            "invalid replacement input",
        )?;
        fs::write(
            repo.join(&input_name),
            concat!(
                r#"{"cwe_ids":["CWE-89"],"locations":[{"path":"./source.py","#,
                r#""start_line":1,"role":"entrypoint"}],"summary":"wide paths","#,
                r#""evidence":"source evidence"}"#,
                "\n",
            ),
        )?;
        let output_link = "i\u{0307}.jsonl";
        if symlinks {
            std::os::windows::fs::symlink_file(&output_name, repo.join(output_link))?;
            std::os::windows::fs::symlink_file(output_link, repo.join("İ.jsonl"))?;
        }
        let expected = concat!(
            r#"{"candidate_id":"candidate-a69fa65a28ed4e55","cwe_ids":["CWE-89"],"#,
            r#""evidence":"source evidence","locations":[{"end_line":1,"#,
            r#""path":"source.py","role":"entrypoint","start_line":1}],"#,
            r#""summary":"wide paths"}"#,
            "\n",
        );
        let candidate = |repo_arg: &Path, input: &Path, scope: &Path, output: &Path| {
            invoke(
                "normalize-candidates",
                &[
                    "--repo-root".into(),
                    repo_arg.into(),
                    "--input".into(),
                    input.into(),
                    "--in-scope-files".into(),
                    scope.into(),
                    "--out".into(),
                    output.into(),
                    "--allow-missing-in-scope".into(),
                ],
            )
        };
        fs::write(&output, "previous output")?;
        for (index, prefix) in [repo.clone(), PathBuf::from("~"), PathBuf::from(".")]
            .into_iter()
            .enumerate()
        {
            let child = candidate(
                &prefix,
                &prefix.join(&input_name),
                &prefix.join(&scope_name),
                &prefix.join(if index == 0 || !symlinks {
                    output_name.clone()
                } else {
                    OsString::from("İ.jsonl")
                }),
            )?;
            if !child.status.success()
                || !child.stderr.is_empty()
                || fs::read(&output)? != expected.as_bytes()
            {
                return Err(io::Error::other(format!(
                    "Wide candidate helper failed: {}",
                    String::from_utf8_lossy(&child.stderr)
                )));
            }
        }
        fs::create_dir(repo.join("blocked-output"))?;
        let child = candidate(
            Path::new("."),
            Path::new(&input_name),
            Path::new(&scope_name),
            Path::new("blocked-output"),
        )?;
        if child.status.code() != Some(2) || !repo.join("blocked-output").is_dir() {
            return Err(io::Error::other(
                "Candidate replacement failure was not preserved",
            ));
        }
        for entry in fs::read_dir(&repo)? {
            if entry?
                .file_name()
                .to_string_lossy()
                .starts_with(".candidates-")
            {
                return Err(io::Error::other(
                    "Candidate temporary output was not removed",
                ));
            }
        }
        for sentinel in &sentinels {
            if fs::read(sentinel)? != b"output sentinel" {
                return Err(io::Error::other(
                    "Candidate helper changed a replacement output",
                ));
            }
        }
        let assessment_name = raw("assessment-", 0xd800);
        let assessment_path = repo.join(&assessment_name);
        let replacement_assessment = repo.join(raw("assessment-", 0xfffd));
        let assessment = r#"{
            "schemaVersion":1,
            "patch":{"repository":"example/project","sourceType":"patch_file","base":"base","head":"head","changedFiles":["src/example.ts"],"sha256":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"},
            "recommendation":"no_op","workflowLabel":"no_op",
            "impact":{"rating":"low","rationale":"No active path changes."},
            "regressionLikelihood":{"rating":"low","rationale":"No live effect."},
            "regressionProtection":{"rating":"strong","rationale":"Fixture validated.","exactHeadChecksPassed":true},
            "recoverability":{"rating":"easy","rationale":"Local change."},
            "confidence":{"rating":"high","rationale":"Known fixture."},
            "applicability":{"status":"no_live_effect","rationale":"Synthetic input."},
            "statusQuoRisk":{"rating":"low","rationale":"No live effect."},
            "autoMergeExclusions":[],"affectedRuntimeRoots":[],"materialBoundaries":[],
            "validation":[{"name":"fixture","status":"passed","protects":"Validator input."}],
            "unknowns":[],"evidencePlan":[]
        }"#;
        fs::write(&assessment_path, assessment)?;
        fs::write(&replacement_assessment, "replacement assessment sentinel")?;
        for input in [assessment_path.clone(), PathBuf::from(&assessment_name)] {
            let child = Command::new(&node)
                .arg(&script)
                .args(["--helper", "validate-patch-risk-assessment"])
                .arg(input)
                .current_dir(&repo)
                .output()?;
            if !child.status.success() || !child.stdout.is_empty() || !child.stderr.is_empty() {
                return Err(io::Error::other(format!(
                    "Wide assessment helper failed: {}",
                    String::from_utf8_lossy(&child.stderr)
                )));
            }
        }
        if fs::read(&assessment_path)? != assessment.as_bytes()
            || fs::read(&replacement_assessment)? != b"replacement assessment sentinel"
        {
            return Err(io::Error::other("Assessment validation changed its input"));
        }
        let worklist_dir = raw("worklist-", 0xdc80);
        let worklist_output = repo.join(&worklist_dir).join(&output_name);
        let worklist_sentinel = repo
            .join(raw("worklist-", 0xfffd))
            .join(&replacement_output);
        fs::create_dir_all(worklist_sentinel.parent().unwrap())?;
        fs::write(&worklist_sentinel, "worklist output sentinel")?;
        for (command, input_flag, row) in [
            (
                "copy-deep-review-input",
                "--rank-input",
                "{\"path\":\"source.py\",\"area\":\"src\",\"preview\":\"source line\"}\n",
            ),
            (
                "select-deep-review-input",
                "--rank-output",
                "{\"path\":\"source.py\",\"area\":\"src\",\"score\":5,\"include\":true,\"reason\":\"source line\"}\n",
            ),
        ] {
            fs::write(repo.join(&input_name), row)?;
            for prefix in [repo.clone(), PathBuf::from("~"), PathBuf::from(".")] {
                let child = invoke(command, &[
                    input_flag.into(), prefix.join(&input_name),
                    "--out".into(), prefix.join(&worklist_dir).join(&output_name),
                ])?;
                if !child.status.success()
                    || !child.stderr.is_empty()
                    || fs::read(&worklist_output)? != b"{\"path\":\"source.py\",\"area\":\"src\"}\r\n"
                {
                    return Err(io::Error::other(format!(
                        "Wide deep-review helper failed: {}",
                        String::from_utf8_lossy(&child.stderr)
                    )));
                }
                fs::remove_file(&worklist_output)?;
            }
        }
        if fs::read(&worklist_sentinel)? != b"worklist output sentinel"
            || fs::read(repo.join(raw("input-", 0xfffd)))? != b"invalid replacement input"
        {
            return Err(io::Error::other(
                "Deep-review helper changed a replacement path",
            ));
        }
        let shards_name = raw("shards-", 0xdc80);
        let shards = repo.join(&shards_name);
        let replacement_shards = repo.join(raw("shards-", 0xfffd));
        fs::create_dir(&replacement_shards)?;
        let shard_sentinel = replacement_shards.join("rank-shard-0001.input.jsonl");
        fs::write(&shard_sentinel, "replacement shard sentinel")?;
        let merge_parent = raw("merged-", 0xd800);
        let merged = repo.join(&merge_parent).join(&output_name);
        let merge_sentinel = repo.join(raw("merged-", 0xfffd)).join(&replacement_output);
        fs::create_dir_all(merge_sentinel.parent().unwrap())?;
        fs::write(&merge_sentinel, "replacement merge sentinel")?;
        let input_rows = [
            "{\"path\":\"first.py\",\"area\":\"src\",\"preview\":\"first\"}\r\n",
            "{\"path\":\"second.py\",\"area\":\"src\",\"preview\":\"second\"}\r\n",
        ];
        let output_rows = [
            "{\"path\":\"first.py\",\"area\":\"src\",\"score\":5,\"include\":true,\"reason\":\"review\"}\r\n",
            "{\"path\":\"second.py\",\"area\":\"src\",\"score\":6,\"include\":true,\"reason\":\"review\"}\r\n",
        ];
        fs::write(repo.join(&input_name), input_rows.concat())?;
        let made = invoke(
            "make-rank-shards",
            &[
                "--rank-input".into(),
                repo.join(&input_name),
                "--out-dir".into(),
                Path::new("~").join(&shards_name),
                "--max-rows".into(),
                "1".into(),
            ],
        )?;
        if !made.status.success() || !made.stderr.is_empty() {
            return Err(io::Error::other(format!(
                "Wide shard creation failed: {}",
                String::from_utf8_lossy(&made.stderr)
            )));
        }
        for (index, input_row) in input_rows.iter().enumerate() {
            let stem = format!("rank-shard-{:04}", index + 1);
            if fs::read(shards.join(format!("{stem}.input.jsonl")))? != input_row.as_bytes() {
                return Err(io::Error::other("Wide input shard bytes changed"));
            }
            fs::write(
                shards.join(format!("{stem}.output.jsonl")),
                output_rows[index],
            )?;
        }
        let validated = invoke(
            "validate-rank-shard",
            &[
                "--input".into(),
                Path::new(&shards_name).join("rank-shard-0001.input.jsonl"),
                "--output".into(),
                Path::new(&shards_name).join("rank-shard-0001.output.jsonl"),
            ],
        )?;
        let merge_args = [
            "--rank-input".into(),
            Path::new(".").join(&input_name),
            "--shard-dir".into(),
            shards.clone(),
            "--out".into(),
            Path::new("~").join(&merge_parent).join(&output_name),
        ];
        let merge_result = invoke("merge-rank-outputs", &merge_args)?;
        if !validated.status.success()
            || !validated.stderr.is_empty()
            || !merge_result.status.success()
            || !merge_result.stderr.is_empty()
            || fs::read(&merged)? != output_rows.concat().as_bytes()
        {
            return Err(io::Error::other(format!(
                "Wide shard validation/merge failed: {}{}",
                String::from_utf8_lossy(&validated.stderr),
                String::from_utf8_lossy(&merge_result.stderr)
            )));
        }
        let mut malformed_name = raw("rank-shard-", 0xdfff);
        malformed_name.push(".input.jsonl");
        fs::write(shards.join(&malformed_name), "")?;
        let malformed = invoke("merge-rank-outputs", &merge_args)?;
        if malformed.status.code() != Some(1)
            || !String::from_utf8_lossy(&malformed.stderr)
                .contains("Rank input shards must use contiguous canonical names")
            || !String::from_utf8_lossy(&malformed.stderr)
                .contains("rank-shard-\\udfff.input.jsonl")
            || fs::read(&merged)? != output_rows.concat().as_bytes()
            || fs::read(&shard_sentinel)? != b"replacement shard sentinel"
            || fs::read(&merge_sentinel)? != b"replacement merge sentinel"
            || fs::read(repo.join(raw("input-", 0xfffd)))? != b"invalid replacement input"
        {
            return Err(io::Error::other(
                "Wide shard discovery or replacement paths changed",
            ));
        }
        fs::remove_file(shards.join(&malformed_name))?;
        let pool_name = raw("pool-", 0xd800);
        let plan_name = raw("plan-", 0xdfff);
        let pool = repo.join(&pool_name);
        let pool_shards = pool.join("rank_shards");
        fs::create_dir(&pool)?;
        fs::rename(&shards, &pool_shards)?;
        let plan = pool.join(&plan_name);
        let plan_sentinel = pool.join(raw("plan-", 0xfffd));
        fs::write(&plan_sentinel, "replacement plan sentinel")?;
        let made_plan = invoke(
            "make-rank-pool-plan",
            &[
                "--shard-dir".into(),
                Path::new("~").join(&pool_name).join("rank_shards"),
                "--usable-worker-slots".into(),
                "2".into(),
                "--out".into(),
                Path::new(&pool_name).join(&plan_name),
            ],
        )?;
        if !made_plan.status.success() || !made_plan.stderr.is_empty() {
            return Err(io::Error::other(format!(
                "Wide pool plan creation failed: {}",
                String::from_utf8_lossy(&made_plan.stderr)
            )));
        }
        let plan_bytes = fs::read(&plan)?;
        let expected_plan = concat!(
            "{\r\n  \"ranking_worker_count\": 2,\r\n  \"schema_version\": 1,\r\n",
            "  \"shard_count\": 2,\r\n  \"strategy\": \"round_robin\",\r\n  \"workers\": [\r\n",
            "    {\r\n      \"input_shards\": [\r\n        \"rank-shard-0001.input.jsonl\"\r\n      ],\r\n",
            "      \"output_shards\": [\r\n        \"rank-shard-0001.output.jsonl\"\r\n      ],\r\n      \"slot\": 1\r\n    },\r\n",
            "    {\r\n      \"input_shards\": [\r\n        \"rank-shard-0002.input.jsonl\"\r\n      ],\r\n",
            "      \"output_shards\": [\r\n        \"rank-shard-0002.output.jsonl\"\r\n      ],\r\n      \"slot\": 2\r\n    }\r\n  ]\r\n}\r\n",
        );
        if plan_bytes != expected_plan.as_bytes() {
            return Err(io::Error::other("Wide pool assignment bytes changed"));
        }
        let pool_args = [
            "--plan".into(),
            plan.clone(),
            "--shard-dir".into(),
            Path::new(".").join(&pool_name).join("rank_shards"),
        ];
        let mut worker_args = pool_args.to_vec();
        worker_args.extend(["--slot".into(), "1".into()]);
        let worker = invoke("validate-rank-worker", &worker_args)?;
        let complete = invoke("validate-rank-pool", &pool_args)?;
        if !worker.status.success()
            || !worker.stderr.is_empty()
            || !worker.stdout.starts_with(b"RANK_WORKER_RECEIPT ")
            || !complete.status.success()
            || !complete.stderr.is_empty()
            || complete.stdout != b"Validated 2 ranking workers, 2 shards, and 2 ranking rows\r\n"
            || fs::read(&plan)? != plan_bytes
            || fs::read(&plan_sentinel)? != b"replacement plan sentinel"
        {
            return Err(io::Error::other(format!(
                "Wide pool validation failed: {}{}",
                String::from_utf8_lossy(&worker.stderr),
                String::from_utf8_lossy(&complete.stderr)
            )));
        }
        let scopes_name = raw("requested-", 0xd800);
        let manifest_name = raw("manifest-", 0xdc80);
        let coverage_name = raw("coverage-", 0xdfff);
        let scopes_path = repo.join(&scopes_name);
        let manifest_path = repo.join(&manifest_name);
        let coverage_path = repo.join(&coverage_name);
        let scope_contents = r#"["src","\udfff","src"]"#;
        fs::write(&scopes_path, scope_contents)?;
        for prefix in ["requested-", "manifest-", "coverage-"] {
            fs::write(repo.join(raw(prefix, 0xfffd)), "replacement scope sentinel")?;
        }
        let manifest_before =
            r#"{"scan":{"scope":{"includePaths":["old"],"excludePaths":[]}},"sha256":"unchanged"}"#;
        let coverage_before = r#"{"includePaths":["old"],"excludePaths":[]}"#;
        let manifest_after = concat!(
            "{\n  \"scan\": {\n    \"scope\": {\n      \"includePaths\": [\n",
            "        \"src\",\n        \"\\udfff\",\n        \"src\"\n      ],\n",
            "      \"excludePaths\": []\n    }\n  },\n  \"sha256\": \"unchanged\"\n}\n",
        );
        let coverage_after = concat!(
            "{\n  \"includePaths\": [\n    \"src\",\n    \"\\udfff\",\n",
            "    \"src\"\n  ],\n  \"excludePaths\": []\n}\n",
        );
        for prefix in [repo.clone(), PathBuf::from("~"), PathBuf::from(".")] {
            fs::write(
                &manifest_path,
                format!("{manifest_before}{}", " ".repeat(512)),
            )?;
            fs::write(
                &coverage_path,
                format!("{coverage_before}{}", " ".repeat(512)),
            )?;
            let bind_args = [
                "--scopes-file".into(),
                prefix.join(&scopes_name),
                "--manifest".into(),
                prefix.join(&manifest_name),
                "--coverage".into(),
                prefix.join(&coverage_name),
            ];
            let bound = invoke("bind-repo-scopes", &bind_args)?;
            if !bound.status.success()
                || !bound.stderr.is_empty()
                || bound.stdout != b"Bound 3 requested scopes into the scan contract\r\n"
                || fs::read(&manifest_path)? != manifest_after.as_bytes()
                || fs::read(&coverage_path)? != coverage_after.as_bytes()
                || fs::read(&scopes_path)? != scope_contents.as_bytes()
            {
                return Err(io::Error::other(format!(
                    "Wide scope binding failed: {}",
                    String::from_utf8_lossy(&bound.stderr)
                )));
            }
            fs::write(&coverage_path, "{")?;
            let invalid = invoke("bind-repo-scopes", &bind_args)?;
            if invalid.status.code() != Some(1)
                || !invalid.stdout.is_empty()
                || invalid.stderr != b"Unable to bind requested scopes into the scan contract\r\n"
                || fs::read(&manifest_path)? != manifest_after.as_bytes()
                || fs::read(&coverage_path)? != b"{"
            {
                return Err(io::Error::other("Invalid wide scope contract was changed"));
            }
        }
        for prefix in ["requested-", "manifest-", "coverage-"] {
            if fs::read(repo.join(raw(prefix, 0xfffd)))? != b"replacement scope sentinel" {
                return Err(io::Error::other("Scope binding changed a replacement path"));
            }
        }
        println!(
            "{{\"policyHelperRawPaths\":true,\"candidateHelperRawPaths\":true,\"assessmentHelperRawPaths\":true,\"deepReviewHelperRawPaths\":true,\"rankShardHelperRawPaths\":true,\"rankPoolHelperRawPaths\":true,\"bindScopesHelperRawPaths\":true,\"directoryIdentity\":true,\"policySymlinkBoundary\":{symlinks}}}"
        );
        Ok(())
    }

    let mut args = env::args_os().skip(1);
    let node = args.next().expect("Node executable path");
    let script = args.next().expect("Windows wide proof script");
    let root = PathBuf::from(args.next().expect("Proof fixture directory")).join("wide-process");
    fs::create_dir(&root)?;
    let result = if args.next().is_some_and(|argument| argument == "policy") {
        policy_proof(node, script, &root)
    } else {
        run(node, script, &root)
    };
    let cleanup = fs::remove_dir_all(&root);
    result?;
    cleanup
}

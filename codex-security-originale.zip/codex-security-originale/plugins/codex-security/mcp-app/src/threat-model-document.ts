import { spawn } from "node:child_process";
import { join } from "node:path";
import type { ArtifactContext } from "./artifact-context.js";
import {
  artifactDestination,
  readArtifactJsonObject,
  replaceArtifactText,
} from "./artifact-io.js";
import { resolvePythonCommand } from "./python_command.js";

const pendingDocuments = new Map<string, Promise<void>>();

/** Materialize a saved model without making its convenience file a checkpoint gate. */
export async function saveThreatModelDocument(
  context: ArtifactContext,
  threatModel: Record<string, unknown> | undefined,
): Promise<string | undefined> {
  if (threatModel === undefined || context.pluginRoot === undefined) return;
  const previous = pendingDocuments.get(context.root) ?? Promise.resolve();
  const operation = previous.then(() =>
    writeCurrentThreatModelDocument(context),
  );
  const pending = operation.then(() => undefined);
  pendingDocuments.set(context.root, pending);
  try {
    return await operation;
  } finally {
    if (pendingDocuments.get(context.root) === pending) {
      pendingDocuments.delete(context.root);
    }
  }
}

async function writeCurrentThreatModelDocument(
  context: ArtifactContext,
): Promise<string | undefined> {
  try {
    const source = await readArtifactJsonObject(
      context,
      [context.layout === "scan" ? "scan-manifest.json" : "result.json"],
      "saved threat model",
    );
    const document = context.layout === "scan" ? source.scan : source;
    const threatModel =
      document && typeof document === "object" && !Array.isArray(document)
        ? (document as Record<string, unknown>).threatModel
        : undefined;
    if (threatModel === undefined) return;
    const destination = await artifactDestination(
      context,
      ["threatmodel.md"],
      "threat model document",
    );
    const python = context.pythonCommand ?? (await resolvePythonCommand());
    const markdown = await renderThreatModel(python, context.pluginRoot!, {
      threatModel,
      provenance: {
        source: context.layout,
        scanId: context.scanId,
        target: context.repoRoot,
        revision: context.targetRevision,
        snapshotDigest: context.targetContract?.requiredSnapshotDigest,
        status: context.status ?? "running",
        provisional: context.status !== "complete",
        ...(context.scope === undefined
          ? {}
          : { scanScope: { includePaths: [context.scope] } }),
      },
    });
    await replaceArtifactText(destination, markdown);
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    return `The threat model was saved, but threatmodel.md could not be written: ${reason}`;
  }
}

function renderThreatModel(
  python: string,
  pluginRoot: string,
  input: Record<string, unknown>,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn(
      python,
      [
        "-I",
        "-X",
        "utf8",
        join(pluginRoot, "scripts", "threat_model_projection.py"),
        "--input-json-stdin",
      ],
      { stdio: ["pipe", "pipe", "pipe"], windowsHide: true },
    );
    const output: string[] = [];
    const errors: string[] = [];
    child.stdout
      .setEncoding("utf8")
      .on("data", (chunk: string) => output.push(chunk));
    child.stderr
      .setEncoding("utf8")
      .on("data", (chunk: string) => errors.push(chunk));
    child.on("error", reject);
    child.stdin.on("error", reject);
    child.on("close", (code, signal) => {
      if (code === 0) resolve(output.join(""));
      else
        reject(
          new Error(
            errors.join("").trim() ||
              `Threat-model renderer exited with ${signal ?? code}.`,
          ),
        );
    });
    child.stdin.end(JSON.stringify(input));
  });
}
